# Scentific calculator
fully and funcanilly operate operands by operators and fully work all type of calaculation
