
const display = document.getElementById("display");
const expressionView = document.getElementById("expression");
const statusView = document.getElementById("status");
const angleView = document.getElementById("angleMode");
const memoryStatus = document.getElementById("memoryStatus");
const historyList = document.getElementById("historyList");

let expression = "";
let cursor = 0;
let degreeMode = true;
let memory = 0;
let answer = 0;
let history = [];
let justCalculated = false;

const functions = new Set([
    "sin", "cos", "tan", "asin", "acos", "atan",
    "sinh", "cosh", "tanh", "sqrt", "cbrt",
    "log", "ln", "log2", "abs", "floor", "ceil",
    "round", "exp10", "expe", "tenpower",
    "npr", "ncr"
]);

function updateDisplay() {
    display.textContent = expression || "0";
    expressionView.textContent = expression
        ? "f(x) = " + expression
        : "";

    memoryStatus.textContent =
        memory !== 0 ? "MEMORY: STORED" : "MEMORY: EMPTY";

    angleView.textContent = degreeMode ? "DEG" : "RAD";
    document.getElementById("degreeBtn")
        .classList.toggle("active", degreeMode);
    document.getElementById("radianBtn")
        .classList.toggle("active", !degreeMode);
}

function insert(text) {
    if (justCalculated) {
        if (/^[0-9.]$/.test(text)) {
            expression = "";
            cursor = 0;
        }
        justCalculated = false;
    }

    expression =
        expression.slice(0, cursor) +
        text +
        expression.slice(cursor);

    cursor += text.length;
    statusView.textContent = "CALCULATING";
    updateDisplay();
}

function clearAll() {
    expression = "";
    cursor = 0;
    justCalculated = false;
    statusView.textContent = "READY";
    updateDisplay();
}

function deleteLast() {
    if (cursor > 0) {
        expression =
            expression.slice(0, cursor - 1) +
            expression.slice(cursor);

        cursor--;
    }

    justCalculated = false;
    updateDisplay();
}

function moveCursor(direction) {
    cursor = Math.max(
        0,
        Math.min(expression.length, cursor + direction)
    );

    statusView.textContent = "CURSOR MOVED";
}

function factorial(n) {
    if (!Number.isInteger(n) || n < 0 || n > 170) {
        throw new Error("Invalid factorial");
    }

    let result = 1;

    for (let i = 2; i <= n; i++) {
        result *= i;
    }

    return result;
}

function permutation(n, r) {
    if (!Number.isInteger(n) || !Number.isInteger(r) ||
        n < 0 || r < 0 || r > n) {
        throw new Error("Invalid nPr");
    }

    return factorial(n) / factorial(n - r);
}

function combination(n, r) {
    if (!Number.isInteger(n) || !Number.isInteger(r) ||
        n < 0 || r < 0 || r > n) {
        throw new Error("Invalid nCr");
    }

    return factorial(n) /
        (factorial(r) * factorial(n - r));
}

// Convert input into mathematical tokens
function tokenize(input) {
    input = input
        .replace(/\[/g, "(")
        .replace(/\]/g, ")")
        .replace(/×/g, "*")
        .replace(/÷/g, "/")
        .replace(/π/g, "pi")
        .replace(/−/g, "-");

    const regex =
        /\s*(?:(\d+(?:\.\d*)?|\.\d+)(?:[eE]([+-]?\d+))?|([a-zA-Z]+)|(\*\*|[+\-*/^(),!%]))/gy;

    let tokens = [];
    let position = 0;

    while (position < input.length) {
        regex.lastIndex = position;
        const match = regex.exec(input);

        if (!match) {
            throw new Error("Invalid expression");
        }

        position = regex.lastIndex;

        if (match[1] !== undefined) {
            let value = Number(
                match[1] + (match[2] ? "e" + match[2] : "")
            );

            tokens.push({ type: "number", value });
        }
        else if (match[3]) {
            tokens.push({
                type: "name",
                value: match[3].toLowerCase()
            });
        }
        else {
            tokens.push({
                type: "symbol",
                value: match[4]
            });
        }
    }

    return tokens;
}

// Recursive descent scientific expression parser
function evaluate(input) {
    const tokens = tokenize(input);
    let position = 0;

    function peek() {
        return tokens[position];
    }

    function consume(value) {
        if (peek() && peek().value === value) {
            position++;
            return true;
        }
        return false;
    }

    function expect(value) {
        if (!consume(value)) {
            throw new Error("Expected " + value);
        }
    }

    function primary() {
        const token = peek();

        if (!token) throw new Error("Unexpected end");

        if (token.type === "number") {
            position++;
            return token.value;
        }

        if (consume("(")) {
            const value = addition();
            expect(")");
            return value;
        }

        if (token.type === "name") {
            position++;
            const name = token.value;

            if (name === "pi") return Math.PI;
            if (name === "e") return Math.E;
            if (name === "phi") return (1 + Math.sqrt(5)) / 2;
            if (name === "ans") return answer;

            if (functions.has(name)) {
                expect("(");

                const a = addition();
                let b;

                if (consume(",")) {
                    b = addition();
                }

                expect(")");

                return runFunction(name, a, b);
            }
        }

        throw new Error("Invalid value");
    }

    function unary() {
        if (consume("+")) return unary();
        if (consume("-")) return -unary();
        return primary();
    }

    function postfix() {
        let value = unary();

        while (true) {
            if (consume("!")) {
                value = factorial(value);
            }
            else if (consume("%")) {
                value /= 100;
            }
            else {
                break;
            }
        }

        return value;
    }

    function power() {
        let value = postfix();

        if (consume("^") || consume("**")) {
            value = Math.pow(value, unary());
        }

        return value;
    }

    function multiplication() {
        let value = power();

        while (true) {
            if (consume("*")) {
                value *= power();
            }
            else if (consume("/")) {
                const divisor = power();
                if (divisor === 0) throw new Error("Division by zero");
                value /= divisor;
            }
            else if (consume("mod")) {
                value %= power();
            }
            else {
                break;
            }
        }

        return value;
    }

    function addition() {
        let value = multiplication();

        while (true) {
            if (consume("+")) {
                value += multiplication();
            }
            else if (consume("-")) {
                value -= multiplication();
            }
            else {
                break;
            }
        }

        return value;
    }

    const result = addition();

    if (position !== tokens.length) {
        throw new Error("Unexpected input");
    }

    if (!Number.isFinite(result)) {
        throw new Error("Math error");
    }

    return result;
}

function runFunction(name, x, y) {
    const toRadians = value =>
        degreeMode ? value * Math.PI / 180 : value;

    const fromRadians = value =>
        degreeMode ? value * 180 / Math.PI : value;

    switch (name) {
        case "sin": return Math.sin(toRadians(x));
        case "cos": return Math.cos(toRadians(x));
        case "tan": return Math.tan(toRadians(x));

        case "asin":
            return fromRadians(Math.asin(x));

        case "acos":
            return fromRadians(Math.acos(x));

        case "atan":
            return fromRadians(Math.atan(x));

        case "sinh": return Math.sinh(x);
        case "cosh": return Math.cosh(x);
        case "tanh": return Math.tanh(x);

        case "sqrt": return Math.sqrt(x);
        case "cbrt": return Math.cbrt(x);

        case "log": return Math.log10(x);
        case "ln": return Math.log(x);
        case "log2": return Math.log2(x);

        case "abs": return Math.abs(x);
        case "floor": return Math.floor(x);
        case "ceil": return Math.ceil(x);
        case "round": return Math.round(x);

        case "exp10": return Math.pow(10, x);
        case "expe": return Math.exp(x);
        case "tenpower": return Math.pow(2, x);

        case "npr": return permutation(x, y);
        case "ncr": return combination(x, y);

        default: throw new Error("Unknown function");
    }
}

function calculate() {
    if (!expression.trim()) return;

    try {
        const original = expression;
        const result = evaluate(expression);

        answer = result;

        const formatted = Number(
            result.toPrecision(12)
        ).toString();

        history.unshift({
            expression: original,
            result: formatted
        });

        history = history.slice(0, 30);

        expression = formatted;
        cursor = expression.length;
        justCalculated = true;

        statusView.textContent = "CALCULATION SUCCESSFUL";

        renderHistory();
        updateDisplay();

    } catch (error) {
        statusView.textContent = "ERROR: " + error.message;
        display.textContent = "Math Error";
    }
}

// Scientific function buttons
function applyFunction(name) {
    insert(name + "(");
}

function applySuffix(suffix) {
    insert(suffix);
}

function applyPrefix(prefix) {
    insert(prefix);
}

// Handle all calculator actions
function handleAction(action) {
    switch (action) {

        case "clear":
            clearAll();
            break;

        case "delete":
            deleteLast();
            break;

        case "calculate":
            calculate();
            break;

        case "percent":
            applySuffix("%");
            break;

        case "sign":
            insert("-");
            break;

        case "square":
            insert("^2");
            break;

        case "cube":
            insert("^3");
            break;

        case "reciprocal":
            insert("1/(");
            break;

        case "factorial":
            applySuffix("!");
            break;

        case "pi":
            insert("pi");
            break;

        case "e":
            insert("e");
            break;

        case "phi":
            insert("phi");
            break;

        case "ans":
            insert("ans");
            break;

        case "decimal":
            insert(".");
            break;

        case "doublezero":
            insert("00");
            break;

        case "exp":
            insert("*10^");
            break;

        case "mod":
            insert("mod");
            break;

        case "bracket":
            insert("(");
            break;

        case "left":
            moveCursor(-1);
            break;

        case "right":
            moveCursor(1);
            break;

        case "npr":
        case "ncr":
            insert(action + "(");
            break;

        case "mc":
            memory = 0;
            updateDisplay();
            statusView.textContent = "MEMORY CLEARED";
            break;

        case "mr":
            insert(String(memory));
            break;

        case "mplus":
            memory += evaluate(expression || "0");
            updateDisplay();
            statusView.textContent = "MEMORY ADDED";
            break;

        case "mminus":
            memory -= evaluate(expression || "0");
            updateDisplay();
            statusView.textContent = "MEMORY SUBTRACTED";
            break;

        default:
            if (functions.has(action)) {
                applyFunction(action);
            }
    }
}

// Bind keypad buttons
document.querySelectorAll(".key").forEach(button => {
    button.addEventListener("click", () => {
        if (button.dataset.value !== undefined) {
            insert(button.dataset.value);
        } else {
            handleAction(button.dataset.action);
        }
    });
});

// DEG / RAD
document.getElementById("degreeBtn").onclick = () => {
    degreeMode = true;
    updateDisplay();
};

document.getElementById("radianBtn").onclick = () => {
    degreeMode = false;
    updateDisplay();
};

// History
function renderHistory() {
    if (!history.length) {
        historyList.innerHTML = `
            <div class="empty-history">
                <span>∑</span>
                <p>No calculations yet</p>
            </div>`;
        return;
    }

    historyList.replaceChildren();

    history.forEach(item => {
        const card = document.createElement("div");
        card.className = "history-item";

        const exp = document.createElement("div");
        exp.className = "history-expression";
        exp.textContent = item.expression;

        const result = document.createElement("div");
        result.className = "history-result";
        result.textContent = "= " + item.result;

        card.append(exp, result);

        card.addEventListener("click", () => {
            expression = item.result;
            cursor = expression.length;
            justCalculated = true;
            updateDisplay();
        });

        historyList.appendChild(card);
    });
}

document.getElementById("clearHistory").onclick = () => {
    history = [];
    renderHistory();
};

document.getElementById("historyBtn").onclick = () => {
    document.querySelector(".history-panel")
        .scrollIntoView({ behavior: "smooth" });
};

document.getElementById("copyBtn").onclick = async () => {
    try {
        await navigator.clipboard.writeText(display.textContent);
        statusView.textContent = "RESULT COPIED";
    } catch {
        statusView.textContent = "COPY NOT AVAILABLE";
    }
};

// Light / dark theme
document.getElementById("themeBtn").onclick = () => {
    document.body.classList.toggle("light");
};

// Keyboard support
document.addEventListener("keydown", event => {
    const key = event.key;

    if (/^[0-9.+\-*/^()]$/.test(key)) {
        insert(key);
    }
    else if (key === "Enter" || key === "=") {
        event.preventDefault();
        calculate();
    }
    else if (key === "Backspace") {
        deleteLast();
    }
    else if (key === "Escape") {
        clearAll();
    }
    else if (key === "ArrowLeft") {
        moveCursor(-1);
    }
    else if (key === "ArrowRight") {
        moveCursor(1);
    }
    else if (key === "!") {
        applySuffix("!");
    }
    else if (key === "%") {
        applySuffix("%");
    }
});

// Initialize
updateDisplay();
renderHistory();
